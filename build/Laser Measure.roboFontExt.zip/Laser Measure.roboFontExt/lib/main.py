from laserMeasure import subscriber

subscriber.main()
